import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class TimeCGI {
    public static void main(String[] args) {
        System.out.println("Content-Type: text/html\n");

        try {
            // Read the timezone offset from the backend file
            String content = Files.readString(Paths.get("/var/www/html/timezone.txt")).trim();
            int offset = Integer.parseInt(content);

            // Get the current time in GMT and apply offset
            ZonedDateTime currentTime = ZonedDateTime.now(ZoneOffset.UTC).plusHours(offset);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

            // Output HTML
            System.out.println("<html><head><title>Current Time</title></head><body>");
            System.out.println("<p>The current time in " + (offset == 2 ? "South Africa" : "Ghana") + " is " + currentTime.format(formatter) + "</p>");
            System.out.println("<a href=\"/cgi-bin/set_time.cgi?offset=2\">Switch to South African Time</a><br>");
            System.out.println("<a href=\"/cgi-bin/set_time.cgi?offset=0\">Switch to Ghana Time</a>");
            System.out.println("</body></html>");
        } catch (IOException | NumberFormatException e) {
            System.out.println("<p>Error reading timezone file!</p>");
        }
    }
}
