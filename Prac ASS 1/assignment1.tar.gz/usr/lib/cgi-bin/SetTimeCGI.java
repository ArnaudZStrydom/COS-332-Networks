import java.io.*;
import java.nio.file.*;
import java.util.Map;

public class SetTimeCGI {
    public static void main(String[] args) {
        System.out.println("Content-Type: text/html\n");

        try {
            // Read the QUERY_STRING (CGI environment variable for GET parameters)
            Map<String, String> env = System.getenv();
            String query = env.getOrDefault("QUERY_STRING", "");

            // Extract 'offset' value
            String offset = "2"; // Default to South African time
            if (query.startsWith("offset=")) {
                offset = query.split("=")[1];
            }

            // Update the backend file with the new timezone offset
            Files.writeString(Paths.get("/var/www/html/timezone.txt"), offset);

            // Output response HTML
            System.out.println("<html><head><title>Time Zone Updated</title></head><body>");
            System.out.println("<p>Time zone updated to " + (offset.equals("2") ? "South Africa" : "Ghana") + ".</p>");
            System.out.println("<a href=\"/cgi-bin/time.cgi\">Back to Time Page</a>");
            System.out.println("</body></html>");
        } catch (IOException e) {
            System.out.println("<p>Error writing to timezone file!</p>");
        }
    }
}

